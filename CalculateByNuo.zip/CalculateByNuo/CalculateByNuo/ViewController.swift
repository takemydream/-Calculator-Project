//
//  ViewController.swift
//  CalculateByNuo
//
//  Created by 陈书坚 on 2017/4/27.
//  Copyright © 2017年 斯坦福公开课学习. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//界面属性
    
    //展示界面
    @IBOutlet weak var ShowLabel: UILabel!
    //获取界面值
    var ShowLabelValue: String {
        get{
            return ShowLabel.text!
        }
        set{
            ShowLabel.text! = String(newValue)
        }
    }
    //定义一个空的 text 的存储列表,
    var TextList = Array<String>()


//按钮属性键入
    
    //清空展示界面判断 bool 量
    var ShouldCleanLabel = true
    
    //数字以及括号按钮功能
    @IBAction func NumberButton(_ sender: UIButton) {
        let Diget = sender.currentTitle!
        if ShouldCleanLabel {
            ShowLabelValue = Diget
            ShouldCleanLabel = false
        }else{
            ShowLabelValue = ShowLabelValue + Diget
        }
    }
    
    //C 键功能
    @IBAction func CButton() {
        let CountShowLabel = ShowLabelValue.characters.count
        let ShowLabelBefore = ShowLabel.text!
        if  CountShowLabel > 1{
            print("//C 键功能板块  :","C之前g个数为",ShowLabelValue.characters.count,"之后为",ShowLabelValue.characters.count - 1)
            //实现退格
            let Demo1 = ShowLabelValue.index(ShowLabelValue.startIndex, offsetBy: CountShowLabel - 1)
            ShowLabelValue = ShowLabelValue.substring(to: Demo1)
        }else{
            ShowLabelValue = String(0)
            ShouldCleanLabel = true
        }
        print("//C 键功能板块  :","之前的为",ShowLabelBefore,"之后的为",ShowLabel.text!) //调试用,查看元素是否减少
    }
    
    //AC 键功能
    @IBAction func ACButton() {
        ShowLabel.text = "0"
        ShouldCleanLabel = true
    }
    
    //等于号功能
    @IBAction func EqualFunc(_ sender: UIButton) {
        //获取ShowLabel内容并按希望的方式存入 ShowLabelForCalculate
        var ShowLabelForCalculate = Array<String>()           //定义一个空列表用于存储展示栏的元素 名为 ShowLabelForCalculater
        
        for EveryCharacter in ShowLabel.text!.characters{
            ShowLabelForCalculate.append(String(EveryCharacter))
        }
        
        print("按下等号的 ShowLabelForCalculate, //定义一个空列表用于存储展示栏的元素" , ShowLabelForCalculate)
        
        ShowLabel.text = SerchBracket(ListB: ShowLabelForCalculate)
    
        ShouldCleanLabel = true
    }

    
    //把List 转为计算形式的 list 功能方法 Array<String> ->Array<String>
    func ChangeToTypeForCalculate(ListBefore: Array<String>) -> Array<String>{
        var ListForCalculateLater = [String]()                  //ListForCalculateLater 表示用于存储转换后可用于计算处理的 list
        ListForCalculateLater.removeAll()
        //获取 ListBefore 内容并按希望的方式存入 ListForCalculateLater
        for EveryCharacter in ListBefore{
            switch EveryCharacter {
            case "+" :
                ListForCalculateLater.append(" ")
                ListForCalculateLater.append("+")
                ListForCalculateLater.append(" ")
                
            case "−" :
                ListForCalculateLater.append(" ")
                ListForCalculateLater.append("-")
                ListForCalculateLater.append(" ")
                
            case "×" :
                ListForCalculateLater.append(" ")
                ListForCalculateLater.append("×")
                ListForCalculateLater.append(" ")
                
            case "÷" :
                ListForCalculateLater.append(" ")
                ListForCalculateLater.append("÷")
                ListForCalculateLater.append(" ")
                
            default :
                ListForCalculateLater.append(EveryCharacter)
            }
        }
        print("ListForCalculateLater为" , ListForCalculateLater)
        //转换为 String ,临时用于转换用的 string 命名为 StringListForChange
        var StringListForChange : String = ""
        for n in ListForCalculateLater{
            StringListForChange = StringListForChange + n
        }
        print("转换后的StringListForChange为",StringListForChange)
        let ListForCalculateFinal:Array<String> = StringListForChange.components(separatedBy: " ")
        print("把 StringListForChange按空格分割后 存入ListForCalculateFinal为",ListForCalculateFinal)
        return ListForCalculateFinal
    }
    
    
    //计算加减乘除的具体方法 Array<String> ->String
    func CalculateFuc(ListA: Array<String>) -> String {
        var ListD: Array<String> = ListA
        var n = ListD.count
        while n > 1 {
            if ListD.contains("÷"){
                let demo1 : Int = Int(ListD.index(of: "÷")!)//  demo1为÷所在的位置
                ListD[demo1 - 1 ] = String(Double(ListD[demo1 - 1])! / Double(ListD[demo1 + 1])!)
                ListD.remove(at: demo1 + 1)
                ListD.remove(at: demo1)
            }else if ListD.contains("×"){
                let demo2 : Int = Int(ListD.index(of: "×")!)//demo2为×所在的位置
                ListD[demo2 - 1 ] = String(Double(ListD[demo2 - 1])! * Double(ListD[demo2 + 1])!)
                ListD.remove(at: demo2 + 1)
                ListD.remove(at: demo2)
            }else if ListD.contains("+") || ListD.contains("-"){
                let z = ListD.count - 1 //z 为传入列表的尾标最大值
                print("z为传入列表的尾标最大值",z)
                while ListD.count > 1 {
                    if ListD[1] == "+"{
                        ListD[0] = String(Double(ListD[0])! + Double(ListD[2])!)
                        ListD.remove(at: 1)
                        ListD.remove(at: 1)
                        print("ListD",ListD)
                    }else if ListD[1] == "-"{
                        ListD[0] = String(Double(ListD[0])! - Double(ListD[2])!)
                        ListD.remove(at: 1)
                        ListD.remove(at: 1)
                        print("ListD",ListD)
                    }else{
                        print("ListD[1]为 ",ListD[1],"查看 ListD[1]是否为 nil")
                    }
                }
                
            }else{print("//计算加减乘除的具体方法 <模块>,,出问题")}
            n = ListD.count
            print("计算后的值为:",ListD)
        }
        return ListD[0]
    }
        
    
    //寻找括号并且计算出括号内的值 Array<String> ->String
    func SerchBracket(ListB: Array<String>) ->String{
        
        var ListImport = ListB                                      //ListImport 为导入的参数 ListB 的副本
        
        for n in ListImport{                                             //遍历 参数listImport查询")"
            
            if n == String(")") {                                           //找到第一个")"
                
                var ListForCountFrontBracket = [Int]()              //建立一个空的列表用于存储索引值 K ,列表名为 ListForCountFrontBranket
                var LastIndexOfFrontBracket : Int                       //用于存储最后一个"("的尾标
                let FirstIndexOfBackBracket = Int(ListImport.index(of: ")")!)     //第一个")"的尾标
                print("第一个\")\"的尾标FirstIndexOfBackBracket为",FirstIndexOfBackBracket)
                for k in 0...FirstIndexOfBackBracket - 1{                   //通过索引 k 来遍历{ 0 到 第一个")"的所有索引值}
                    if ListImport[k] == "(" {                            //查找期间所有的 "(" 的索引值 并存入 ListForCountFrontBranket
                        ListForCountFrontBracket.append(k)
                        
                    }else{print("位置//寻找括号并且计算 未找到匹配的前括号")
                    ShowLabel.text = "括号数不对,请按 CA 重新开始"}
                }
                LastIndexOfFrontBracket = Int(ListForCountFrontBracket[ListForCountFrontBracket.count - 1])   //此为最后一个前括号"("的尾标
                
                var StringTextForCalculateBetweenNearBracket :Array<String> = []
                
                print("ListImport为", ListImport)
                for z in LastIndexOfFrontBracket + 1...FirstIndexOfBackBracket - 1 {                //把相邻的括号中的数据存到一个list: StringTextForCalculateBetweenNearBracket ,z 为括号间的尾标(包括括号的尾标)
                    StringTextForCalculateBetweenNearBracket.append(ListImport[z])
                    ListImport[z] = ""                                                       //在 ListImport中用 "" 替换已存储到 StringTextForCalculateBetweenNearBracket的值   <@1>
                    print("当 z 为",z,"  StringTextForCalculateBetweenNearBracket为",StringTextForCalculateBetweenNearBracket)
                    print("当 z 为",z,"  ListImport 为", ListImport)
                }
                //删除ListImport 中 用 "" 替换的位置 ,后面的在 ListImport 中全部去除   [参看<@1>]
                for _ in LastIndexOfFrontBracket + 1...FirstIndexOfBackBracket {
                    ListImport.remove(at: LastIndexOfFrontBracket + 1)
                }
                print("ListImport 计算完本括号后为", ListImport)    //理应为"("
                
                //把存储计算用的 StringTextForCalculateBetweenNearBracket 转换为可用于计算的列表并且计算出括号内的值顶替这段括号所有元素
                let CalculateBetweenNearBracket = CalculateFuc(ListA:ChangeToTypeForCalculate(ListBefore: StringTextForCalculateBetweenNearBracket)) //转换为可用于计算的列表,并且计算返回括号内的值Calcul.....
               
                //在 ListIpmort 里顶替这段括号删减后剩余的唯一开头元素:"("的在 ListImport 中的位置: LastIndexOfFrontBracket
                ListImport[LastIndexOfFrontBracket] = CalculateBetweenNearBracket
                
                print("ListImport 计算完本括号后为", ListImport)
            }
        }
        //跳出了检查是否存在括号的循环,检查 ListImport 的剩余元素 是否唯一,不唯一进行无括号的最后运算;唯一则输出唯一元素 returnlist[0]
        if ListImport.count > 1{
            ListImport[0] = CalculateFuc(ListA: ChangeToTypeForCalculate(ListBefore: ListImport))
        }
        return ListImport[0]
    }
    

}

